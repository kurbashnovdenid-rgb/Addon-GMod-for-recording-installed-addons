-- ===== ЕДИНСТВЕННОЕ МЕСТО, ГДЕ МЕНЯЕТСЯ ПУТЬ =====
local FIXED_TARGET = "D:\\GModTools\\addons_list_search.txt"
-- ==================================================

concommand.Add("addons_list_search", function()
    local addons = engine.GetAddons()
    if not addons or #addons == 0 then print("[Addons] Список пуст.") return end

    local out = "=== Addons List ===\nTotal: " .. #addons .. "\n\n"
    for _, a in ipairs(addons) do
        out = out .. string.format("ID: %s | Title: %s\n", a.wsid or "?", a.title or "?")
    end
    file.Write("_addons_export.txt", out)

    -- HEX-кодируем фиксированный путь для transfer.ps1
    local hexPath = FIXED_TARGET:gsub(".", function(c) return string.format("%02x", string.byte(c)) end)
    if file.Exists("_addons_result.txt", "data") then file.Delete("_addons_result.txt") end
    file.Write("_addons_target.txt", hexPath)
    print("[Addons] Сохраняю список...")

    local t0 = SysTime()
    local tn = "addons_search_" .. tostring(math.random(1, 1e9))
    timer.Create(tn, 0.5, 0, function()
        if SysTime() - t0 > 15 then
            print("[Addons] ТАЙМАУТ: transfer.ps1 не запущен.")
            timer.Remove(tn) return
        end
        if file.Exists("_addons_result.txt", "data") then
            local r = (file.Read("_addons_result.txt", "data") or ""):Trim()
            timer.Remove(tn); file.Delete("_addons_result.txt")
            local decoded = r:gsub("%x%x", function(h) return string.char(tonumber(h, 16)) end)
            local s, m = string.match(decoded, "^(%u+):(.*)$")
            if s == "OK" then
                print("[Addons] Путь успешно изменен: " .. (m or ""))
            else
                print("[Addons] ОШИБКА: " .. (m or decoded))
            end
        end
    end)
end, nil, "Сохраняет список ваших аддонов в фиксированный файл.")